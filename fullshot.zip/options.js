"use strict";
(() => {
  // src/lib/settings.ts
  var DEFAULTS = {
    engine: "stitch",
    format: "png",
    quality: 0.92,
    filenameTemplate: "{domain} {date} {time}",
    captureDelayMs: 150,
    hideSticky: true,
    freezeAnimations: true,
    prescroll: true,
    afterCapture: "editor",
    pdfPageMode: "single",
    saveAs: false,
    maxCaptureHeight: 4e4,
    historyLimit: 30
  };
  async function getSettings() {
    const stored = await chrome.storage.sync.get({ ...DEFAULTS });
    return { ...DEFAULTS, ...stored };
  }
  async function saveSettings(patch) {
    await chrome.storage.sync.set(patch);
  }

  // src/options/options.ts
  var $ = (sel) => document.querySelector(sel);
  var FIELDS = [
    "engine",
    "captureDelayMs",
    "prescroll",
    "hideSticky",
    "freezeAnimations",
    "maxCaptureHeight",
    "format",
    "quality",
    "filenameTemplate",
    "afterCapture",
    "pdfPageMode",
    "saveAs",
    "historyLimit"
  ];
  var savedTimer;
  function flashSaved() {
    const el = $("#saved");
    el.hidden = false;
    clearTimeout(savedTimer);
    savedTimer = setTimeout(() => {
      el.hidden = true;
    }, 1500);
  }
  async function updateTurboUi() {
    const engine = $("#engine").value;
    const granted = await chrome.permissions.contains({ permissions: ["debugger"] });
    $("#grantDebugger").hidden = engine !== "turbo" || granted;
  }
  async function load() {
    const settings = await getSettings();
    for (const key of FIELDS) {
      const el = document.getElementById(key);
      if (!el) continue;
      if (el instanceof HTMLInputElement && el.type === "checkbox") {
        el.checked = Boolean(settings[key]);
      } else {
        el.value = String(settings[key]);
      }
    }
    $("#qualityOut").value = `${Math.round(settings.quality * 100)}%`;
    await updateTurboUi();
  }
  for (const key of FIELDS) {
    const el = document.getElementById(key);
    if (!el) continue;
    el.addEventListener("change", async () => {
      let value;
      if (el instanceof HTMLInputElement && el.type === "checkbox") {
        value = el.checked;
      } else if (typeof DEFAULTS[key] === "number") {
        value = Number(el.value);
      } else {
        value = el.value;
      }
      await saveSettings({ [key]: value });
      if (key === "quality") {
        $("#qualityOut").value = `${Math.round(Number(el.value) * 100)}%`;
      }
      if (key === "engine") {
        await updateTurboUi();
        if (el.value === "turbo") {
          const granted = await chrome.permissions.request({ permissions: ["debugger"] });
          if (!granted) {
            await saveSettings({ engine: "stitch" });
            el.value = "stitch";
          }
          await updateTurboUi();
        }
      }
      flashSaved();
    });
  }
  $("#grantDebugger").addEventListener("click", async () => {
    await chrome.permissions.request({ permissions: ["debugger"] });
    await updateTurboUi();
  });
  $("#editShortcuts").addEventListener("click", (e) => {
    e.preventDefault();
    void chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
  });
  void load();
})();
