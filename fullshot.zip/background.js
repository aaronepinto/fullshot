"use strict";
(() => {
  // src/lib/settings.ts
  var DEFAULTS = {
    engine: "stitch",
    format: "png",
    quality: 0.92,
    filenameTemplate: "{domain} {date} {time}",
    captureDelayMs: 150,
    hideSticky: true,
    freezeAnimations: true,
    prescroll: true,
    afterCapture: "editor",
    pdfPageMode: "single",
    saveAs: false,
    maxCaptureHeight: 4e4,
    historyLimit: 30
  };
  async function getSettings() {
    const stored = await chrome.storage.sync.get({ ...DEFAULTS });
    return { ...DEFAULTS, ...stored };
  }

  // src/lib/db.ts
  var DB_NAME = "fullshot";
  var DB_VERSION = 1;
  var dbPromise = null;
  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        const captures = db.createObjectStore("captures", { keyPath: "id" });
        captures.createIndex("createdAt", "createdAt");
        db.createObjectStore("tiles", { keyPath: "key" }).createIndex("capId", "capId");
        db.createObjectStore("strips", { keyPath: "key" }).createIndex("capId", "capId");
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }
  function tx(stores, mode, run) {
    return open().then(
      (db) => new Promise((resolve, reject) => {
        const t = db.transaction(stores, mode);
        t.onerror = () => reject(t.error);
        const out = run(t);
        if (out instanceof IDBRequest) {
          out.onsuccess = () => resolve(out.result);
          out.onerror = () => reject(out.error);
        } else {
          out.then(resolve, reject);
        }
      })
    );
  }
  var putCapture = (c) => tx(["captures"], "readwrite", (t) => t.objectStore("captures").put(c));
  var listCaptures = async () => {
    const all = await tx(
      ["captures"],
      "readonly",
      (t) => t.objectStore("captures").getAll()
    );
    return all.sort((a, b) => b.createdAt - a.createdAt);
  };
  var putTile = (tile) => tx(["tiles"], "readwrite", (t) => t.objectStore("tiles").put(tile));
  async function deleteByIndex(store, capId) {
    await tx([store], "readwrite", async (t) => {
      const idx = t.objectStore(store).index("capId");
      await new Promise((resolve, reject) => {
        const req = idx.openCursor(capId);
        req.onsuccess = () => {
          const cursor = req.result;
          if (!cursor) return resolve();
          cursor.delete();
          cursor.continue();
        };
        req.onerror = () => reject(req.error);
      });
    });
  }
  var deleteTiles = (capId) => deleteByIndex("tiles", capId);
  var deleteStrips = (capId) => deleteByIndex("strips", capId);
  async function deleteCapture(capId) {
    await tx(["captures"], "readwrite", (t) => t.objectStore("captures").delete(capId));
    await deleteTiles(capId);
    await deleteStrips(capId);
  }
  async function pruneHistory(limit) {
    const all = await listCaptures();
    for (const old of all.slice(Math.max(1, limit))) {
      await deleteCapture(old.id);
    }
  }

  // src/lib/capture-common.ts
  function newCaptureId() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  function makeRecord(opts) {
    return {
      id: opts.id,
      createdAt: Date.now(),
      mode: opts.mode,
      engine: opts.engine,
      title: opts.title,
      url: opts.url,
      width: 0,
      height: 0,
      tileCount: opts.tileCount,
      status: "tiles",
      truncated: opts.truncated,
      clip: opts.clip
    };
  }
  async function dataUrlToBlob(dataUrl) {
    const res = await fetch(dataUrl);
    return res.blob();
  }
  function base64ToBlob(base64, type) {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type });
  }

  // src/cdp.ts
  var PROTOCOL = "1.3";
  var SEGMENT_H = 4e3;
  async function hasDebuggerPermission() {
    return chrome.permissions.contains({ permissions: ["debugger"] });
  }
  async function turboCapture(tabId, capId, requestedClip, maxHeight, onProgress) {
    const target = { tabId };
    await chrome.debugger.attach(target, PROTOCOL);
    try {
      const metrics = await chrome.debugger.sendCommand(target, "Page.getLayoutMetrics");
      const size = metrics.cssContentSize ?? metrics.contentSize;
      if (!size) throw new Error("Could not measure page via CDP");
      const dprEval = await chrome.debugger.sendCommand(target, "Runtime.evaluate", {
        expression: "window.devicePixelRatio",
        returnByValue: true
      });
      const dpr = Math.min(3, Number(dprEval.result?.value) || 1);
      const page = { x: 0, y: 0, w: Math.ceil(size.width), h: Math.ceil(size.height) };
      let clip = requestedClip ? intersect(requestedClip, page) : page;
      let truncated = false;
      if (clip.h > maxHeight) {
        clip = { ...clip, h: maxHeight };
        truncated = true;
      }
      if (clip.w < 1 || clip.h < 1) throw new Error("Empty capture region");
      const segments = [];
      for (let y = clip.y; y < clip.y + clip.h; y += SEGMENT_H) {
        segments.push({ x: clip.x, y, w: clip.w, h: Math.min(SEGMENT_H, clip.y + clip.h - y) });
      }
      let index = 0;
      for (const seg of segments) {
        const shot = await chrome.debugger.sendCommand(target, "Page.captureScreenshot", {
          format: "png",
          captureBeyondViewport: true,
          fromSurface: true,
          clip: { x: seg.x, y: seg.y, width: seg.w, height: seg.h, scale: dpr }
        });
        await putTile({
          key: `${capId}:${index}`,
          capId,
          index,
          x: seg.x,
          y: seg.y,
          cssW: seg.w,
          cssH: seg.h,
          blob: base64ToBlob(shot.data, "image/png")
        });
        index++;
        onProgress(index, segments.length);
      }
      return { clip, tileCount: segments.length, truncated };
    } finally {
      await chrome.debugger.detach(target).catch(() => void 0);
    }
  }
  function intersect(a, b) {
    const x1 = Math.max(a.x, b.x);
    const y1 = Math.max(a.y, b.y);
    const x2 = Math.min(a.x + a.w, b.x + b.w);
    const y2 = Math.min(a.y + a.h, b.y + b.h);
    return { x: x1, y: y1, w: Math.max(0, x2 - x1), h: Math.max(0, y2 - y1) };
  }

  // src/background.ts
  var busyTabs = /* @__PURE__ */ new Set();
  chrome.action.onClicked.addListener((tab) => void startCapture(tab, "full"));
  chrome.commands.onCommand.addListener((command, tab) => {
    const mode = command === "capture-full" ? "full" : command === "capture-visible" ? "visible" : command === "capture-selection" ? "selection" : null;
    if (mode && tab) void startCapture(tab, mode);
  });
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "fs-full",
      title: "Capture full page",
      contexts: ["page", "action"]
    });
    chrome.contextMenus.create({
      id: "fs-visible",
      title: "Capture visible area",
      contexts: ["page", "action"]
    });
    chrome.contextMenus.create({
      id: "fs-selection",
      title: "Capture a region\u2026",
      contexts: ["page", "action"]
    });
    chrome.contextMenus.create({ id: "fs-history", title: "Capture history", contexts: ["action"] });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "fs-history") {
      void chrome.tabs.create({ url: chrome.runtime.getURL("editor.html?history=1") });
      return;
    }
    if (!tab) return;
    const mode = info.menuItemId === "fs-full" ? "full" : info.menuItemId === "fs-visible" ? "visible" : info.menuItemId === "fs-selection" ? "selection" : null;
    if (mode) void startCapture(tab, mode);
  });
  async function startCapture(tab, mode) {
    const tabId = tab.id;
    if (tabId === void 0 || busyTabs.has(tabId)) return;
    busyTabs.add(tabId);
    const badge = badgeFor(tabId);
    try {
      const settings = await getSettings();
      const capId = newCaptureId();
      const injectable = !isRestrictedUrl(tab.url ?? "");
      let selection = null;
      if (mode === "selection") {
        if (!injectable) throw new Error("This page does not allow region selection.");
        selection = await pickRegion(tabId);
        if (!selection) return;
      }
      await badge.set("\u2026");
      let clip;
      let tileCount;
      let truncated = false;
      let engine = settings.engine;
      let title = tab.title ?? "";
      let url = tab.url ?? "";
      if (mode === "visible" || !injectable) {
        ({ clip, tileCount } = await captureVisibleSingle(tab, capId));
        engine = "stitch";
        mode = mode === "selection" ? mode : "visible";
      } else if (engine === "turbo" && await hasDebuggerPermission()) {
        const result = await turboCapture(
          tabId,
          capId,
          selection,
          settings.maxCaptureHeight,
          (done, total) => void badge.set(`${Math.round(done / total * 100)}%`)
        );
        ({ clip, tileCount, truncated } = result);
      } else {
        engine = "stitch";
        const result = await stitchCapture(
          tab,
          capId,
          selection,
          settings,
          (done, total) => badge.set(`${Math.round(done / total * 100)}%`)
        );
        ({ clip, tileCount, truncated } = result);
        title = result.title || title;
        url = result.url || url;
      }
      const record = makeRecord({ id: capId, mode, engine, title, url, tileCount, truncated, clip });
      await putCapture(record);
      await pruneHistory(settings.historyLimit);
      const params = new URLSearchParams({ id: capId });
      if (settings.afterCapture !== "editor") params.set("autodownload", "1");
      await chrome.tabs.create({
        url: chrome.runtime.getURL(`editor.html?${params}`),
        index: tab.index + 1,
        openerTabId: tabId
      });
      await badge.clear();
    } catch (err) {
      console.error("[fullshot] capture failed", err);
      await badge.set("ERR", "#dc2626");
      setTimeout(() => void badge.clear(), 4e3);
    } finally {
      busyTabs.delete(tabId);
    }
  }
  async function stitchCapture(tab, capId, selection, settings, onProgress) {
    const tabId = tab.id;
    await ensureContentScript(tabId, "content-capture.js");
    let metrics = await sendToTab(tabId, {
      type: "fs:measure",
      maxHeight: settings.maxCaptureHeight
    });
    const clipFor = (m) => {
      const page = { x: 0, y: 0, w: m.pageW, h: m.pageH };
      return selection ? intersect2(selection, page) : page;
    };
    let clip = clipFor(metrics);
    if (clip.w < 1 || clip.h < 1) throw new Error("Empty capture region");
    await sendToTab(tabId, {
      type: "fs:prepare",
      hideSticky: settings.hideSticky,
      freezeAnimations: settings.freezeAnimations
    });
    try {
      if (settings.prescroll && clip.h > metrics.vpH) {
        await sendToTab(tabId, {
          type: "fs:prescroll",
          stepY: metrics.vpH,
          maxY: clip.y + clip.h
        });
        metrics = await sendToTab(tabId, {
          type: "fs:measure",
          maxHeight: settings.maxCaptureHeight
        });
        clip = clipFor(metrics);
      }
      const cols = gridPositions(clip.x, clip.w, metrics.vpW, metrics.pageW - metrics.vpW);
      const rows = gridPositions(clip.y, clip.h, metrics.vpH, metrics.pageH - metrics.vpH);
      const total = cols.length * rows.length;
      if (total > 600) throw new Error(`Page needs ${total} tiles \u2014 beyond the safety limit.`);
      let index = 0;
      for (let r = 0; r < rows.length; r++) {
        for (let c = 0; c < cols.length; c++) {
          const pos = await sendToTab(tabId, {
            type: "fs:scrollTo",
            x: cols[c],
            y: rows[r],
            settleMs: settings.captureDelayMs,
            hideFixed: r > 0 || c > 0
          });
          const dataUrl = await captureVisibleThrottled(tab.windowId);
          await putTile({
            key: `${capId}:${index}`,
            capId,
            index,
            x: pos.x,
            y: pos.y,
            cssW: metrics.vpW,
            cssH: metrics.vpH,
            blob: await dataUrlToBlob(dataUrl)
          });
          index++;
          onProgress(index, total);
        }
      }
      return {
        clip,
        tileCount: index,
        truncated: metrics.truncated,
        title: metrics.title,
        url: metrics.url
      };
    } finally {
      await sendToTab(tabId, { type: "fs:restore" }).catch(() => void 0);
    }
  }
  function gridPositions(start, span, step, maxScroll) {
    const positions = [];
    const limit = Math.max(0, maxScroll);
    for (let v = start; v < start + span; v += step) {
      const clamped = Math.max(0, Math.min(v, limit));
      if (positions[positions.length - 1] !== clamped) positions.push(clamped);
      if (clamped >= limit && v > start) break;
    }
    return positions.length ? positions : [0];
  }
  async function captureVisibleSingle(tab, capId) {
    const dataUrl = await captureVisibleThrottled(tab.windowId);
    const cssW = tab.width ?? 0;
    const cssH = tab.height ?? 0;
    await putTile({
      key: `${capId}:0`,
      capId,
      index: 0,
      x: 0,
      y: 0,
      cssW,
      cssH,
      blob: await dataUrlToBlob(dataUrl)
    });
    return { clip: { x: 0, y: 0, w: cssW, h: cssH }, tileCount: 1 };
  }
  var lastShotAt = 0;
  async function captureVisibleThrottled(windowId) {
    const MIN_GAP = 550;
    for (let attempt = 0; ; attempt++) {
      const wait = lastShotAt + MIN_GAP - Date.now();
      if (wait > 0) await sleep(wait);
      lastShotAt = Date.now();
      try {
        return await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
      } catch (err) {
        if (attempt < 4 && String(err).includes("MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND")) {
          await sleep(700);
          continue;
        }
        throw err;
      }
    }
  }
  function pickRegion(tabId) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        cleanup();
        resolve(null);
      }, 18e4);
      const onMessage = (msg, sender) => {
        if (sender.tab?.id !== tabId) return;
        if (msg.type === "fs:selection") {
          cleanup();
          resolve(msg.rect);
        } else if (msg.type === "fs:selection-cancel") {
          cleanup();
          resolve(null);
        }
      };
      const cleanup = () => {
        clearTimeout(timeout);
        chrome.runtime.onMessage.removeListener(onMessage);
      };
      chrome.runtime.onMessage.addListener(onMessage);
      chrome.scripting.executeScript({ target: { tabId }, files: ["content-select.js"] }).catch((err) => {
        cleanup();
        reject(err);
      });
    });
  }
  async function ensureContentScript(tabId, file) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: "fs:ping" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId }, files: [file] });
    }
  }
  async function sendToTab(tabId, msg) {
    const res = await chrome.tabs.sendMessage(tabId, msg);
    if (res && typeof res === "object" && "__err" in res) {
      throw new Error(res.__err);
    }
    return res;
  }
  function isRestrictedUrl(url) {
    if (!url) return true;
    if (/^(chrome|chrome-extension|devtools|edge|about|view-source|chrome-untrusted):/.test(url)) {
      return true;
    }
    return /^https:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com)/.test(url);
  }
  function intersect2(a, b) {
    const x1 = Math.max(a.x, b.x);
    const y1 = Math.max(a.y, b.y);
    const x2 = Math.min(a.x + a.w, b.x + b.w);
    const y2 = Math.min(a.y + a.h, b.y + b.h);
    return { x: x1, y: y1, w: Math.max(0, x2 - x1), h: Math.max(0, y2 - y1) };
  }
  function badgeFor(tabId) {
    return {
      async set(text, color = "#0ea5e9") {
        await chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => void 0);
        await chrome.action.setBadgeText({ tabId, text }).catch(() => void 0);
      },
      async clear() {
        await chrome.action.setBadgeText({ tabId, text: "" }).catch(() => void 0);
      }
    };
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  globalThis.__fullshotStart = startCapture;
})();
